package com.softwiz.osa.user.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserLoginRequest {
    private String email;
    private String password;

    /*public String getEmail() {
        return null;
    }

    public CharSequence getPassword() {
        return null;
    }*/
}
