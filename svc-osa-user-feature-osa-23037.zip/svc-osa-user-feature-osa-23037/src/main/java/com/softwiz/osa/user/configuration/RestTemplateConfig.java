package com.softwiz.osa.user.configuration;

public class RestTemplateConfig {
}
