package com.softwiz.osa.user.controller;

import com.softwiz.osa.user.dto.UserLoginRequest;
import com.softwiz.osa.user.dto.UserRegistrationRequest;
import com.softwiz.osa.user.entity.User;
import com.softwiz.osa.user.exception.UnauthorizedException;
import com.softwiz.osa.user.service.AuthService;
import com.softwiz.osa.user.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class UserControllerTest {
    @InjectMocks
    private UserController userController;
    @Mock
    private UserService userService;
    @Mock
    private AuthService authService;
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    @Test
    public void testRegisterUser_Success() {
        //Arrange
        UserRegistrationRequest registrationRequest = new UserRegistrationRequest();
        when(userService.registerUser(any(UserRegistrationRequest.class))).thenReturn(new User());
        //Act
        ResponseEntity<?> response = userController.register(registrationRequest);
        // Assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("User account created successfully", response.getBody());
    }
    @Test
    public void testRegisterUser_Failure() {
        // Arrange
        UserRegistrationRequest registrationRequest = new UserRegistrationRequest();
        when(userService.registerUser(any(UserRegistrationRequest.class))).thenReturn(null);
        // Act
        ResponseEntity<?> response = userController.register(registrationRequest);
        // Assert
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Failed to create user account", response.getBody());
    }
    @Test
    public void testRegisterUser_Exception() {
        // Arrange
        UserRegistrationRequest registrationRequest = new UserRegistrationRequest();
        when(userService.registerUser(any(UserRegistrationRequest.class))).thenThrow(new RuntimeException("Bad Request"));
        // Act
        ResponseEntity<?> response = userController.register(registrationRequest);
        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Bad Request", response.getBody());
    }
    @Test
    void testLogin_Success() {
        // Arrange
        UserLoginRequest loginRequest = new UserLoginRequest("username", "password");
        Mockito.when(authService.authenticate(any(UserLoginRequest.class))).thenReturn("mockedToken");
        // Act
        ResponseEntity<?> responseEntity = userController.login(loginRequest);
        // Assert
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("User login successful. JWT Token: mockedToken", responseEntity.getBody());
    }
    @Test
    void testLoginFailure_Unauthorized() {
        // Arrange
        UserLoginRequest loginRequest = new UserLoginRequest("username", "password");
        Mockito.when(authService.authenticate(any(UserLoginRequest.class))).thenThrow(new UnauthorizedException("Unauthorized"));
        // Act
        ResponseEntity<?> responseEntity = userController.login(loginRequest);
        // Assert
        assertEquals(HttpStatus.UNAUTHORIZED, responseEntity.getStatusCode());
        assertEquals("Unauthorized", responseEntity.getBody());
    }
    @Test
    void testGetUserById_Success() {
        // Mocking the userService behavior
        Long userId = 1L;
        User mockUser = new User();
        mockUser.setFirstName("Pradeep");
        mockUser.setLastName("Raj");
        mockUser.setUsername("Pradeip");
        mockUser.setEmail("pradeip@gmail.com");
        mockUser.setMobileNumber(1234567890);

        when(userService.getUserById(userId)).thenReturn(mockUser);

        // Calling the controller method
        ResponseEntity<?> responseEntity = userController.getUserById(userId);

        // Verifying the response
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(mockUser, responseEntity.getBody());
    }

    @Test
    void testGetUserById_NotFound() {
        // Mocking the userService behavior for a not found scenario
        Long userId = 2L;
        when(userService.getUserById(userId)).thenReturn(null);

        // Calling the controller method
        ResponseEntity<?> responseEntity = userController.getUserById(userId);

        // Verifying the response
        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        assertEquals("User with ID " + userId + " not found", responseEntity.getBody());
    }

    @Test
    void testGetUserByIdInternalServerError() {
        // Mocking the userService behavior for an internal server error scenario
        Long userId = 3L;
        when(userService.getUserById(userId)).thenThrow(new RuntimeException("Internal Server Error"));

        // Calling the controller method
        ResponseEntity<?> responseEntity = userController.getUserById(userId);

        // Verifying the response
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        assertEquals("Internal Server Error", responseEntity.getBody());
    }

    @Test
    public void testGetAllUsers() {
        // Mocking the service method
        List<User> mockUsers = Arrays.asList(new User(), new User());
        when(userService.getAllUsers()).thenReturn(mockUsers);

        // Calling the controller method
        ResponseEntity<List<User>> responseEntity = userController.getAllUsers();

        // Verifying the response
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(mockUsers, responseEntity.getBody());
    }

    @Test
    public void testGetAllUsersError() {
        // Mocking the service method to throw an exception
        when(userService.getAllUsers()).thenThrow(new RuntimeException("User not found"));

        // Calling the controller method
        ResponseEntity<List<User>> responseEntity = userController.getAllUsers();

        // Verifying the response
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
    }
}