package com.softwiz.osa.Entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "order_item")

public class OrderItem {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long ID;
    @Column (name = "orderItemId")
    private String orderItemId;
    @Column (name = "productId")
    private String productId;
    @Column (name = "productName")
    private String productName;
    @Column (name = "quantity")
    private int quantity;
    @Column (name = "pricePerUnit")
    private double pricePerUnit;

}
