package com.softwiz.osa.Entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "orders")

public class OrderEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long ID;
    @Column (name = "orderId")
    private String orderId;
    @Column (name = "userId")
    private String userId;
    @Column (name = "totalPrice")
    private double totalPrice;
    @Column (name = "orderDate")
    private Date orderDate;
    @Column (name = "status")
    private String status;
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OrderItem> orderItemsList;

}
