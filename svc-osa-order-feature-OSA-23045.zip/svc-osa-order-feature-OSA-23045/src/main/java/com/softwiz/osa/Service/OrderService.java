package com.softwiz.osa.Service;

import com.softwiz.osa.DTO.OrderDTO;

public class OrderService {
    public void create(OrderDTO newOrderDTO) {
    }
}
