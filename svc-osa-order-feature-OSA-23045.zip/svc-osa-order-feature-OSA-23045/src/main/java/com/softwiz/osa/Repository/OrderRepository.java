package com.softwiz.osa.Repository;

import com.softwiz.osa.Entity.OrderEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.criteria.Order;
import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<OrderEntity, Long> {
    List<Order> findByUserId(String UserId);
    List<Order> findByStatus(String status);
}

