package com.softwiz.osa.DTO;

import com.softwiz.osa.Entity.OrderItem;

import java.util.List;

public class OrderDTO {
    private String orderId;
    private String userId;
    private List<OrderItem> orderItems;
    private double totalPrice;
    private String status;

    @Override
    public String toString() {
        return "OrderDTO{" +
                "orderId='" + orderId + '\'' +
                ", userId='" + userId + '\'' +
                ", orderItems=" + orderItems +
                ", totalPrice=" + totalPrice +
                ", status='" + status + '\'' +
                '}';
    }
}
